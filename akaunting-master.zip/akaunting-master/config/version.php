<?php

return [

    'name'      =>  'Akaunting',

    'code'      =>  'Argon',

    'major'     =>  '2',

    'minor'     =>  '0',

    'patch'     =>  '1',

    'build'     =>  '',

    'status'    =>  'Stable',

    'date'      =>  '20-Nov-2019',

    'time'      =>  '18:30',

    'zone'      =>  'GMT +3',

];
